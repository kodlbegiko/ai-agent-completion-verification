"""Completion-verification pilot package."""

__version__ = "0.1.0"
